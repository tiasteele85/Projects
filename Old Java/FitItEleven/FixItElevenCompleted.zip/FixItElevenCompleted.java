import javax.swing.*;
import java.awt.*;
import javax.swing.JApplet;
import javax.swing.JLabel;

public class FixItEleven extends JApplet 
{

	public void init()
	{
	 JLabel lab = new JLabel("Launch and applet");
	 setLayout(new FlowLayout());
	 add(lab);
	}
}
